~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
|
|   HOW TO RUN
|   
|       Comp 86 Assignment 7: Final Project
|       EyeDraw: a drawing application using gaze tracking
|
|           by: Maya DeBellis (mdbel01) and Brooke Weil (bweil01)
|         date: 11 December 2016
|
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

To run a demo of this project, you need to be running on an HTTP server. 

An easy way we did this was by using "python -m SimpleHTTPServer" from 
the main project directory. From there, navigate to your local server in a web
browser (our default location was localhost:8000), and that's it!

As the page says, in order to start drawing, toggle the start button and click
the canvas once to calibrate.